/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a,b;
    printf("enter the two values to swap\n");
    scanf("%d%d",&a,&b);
    printf("before swapping a=%d and B=%d",a,b);
    
    a=a+b;
    b=a-b;
    a=a-b;
    
    printf("after swapping a=%d and b=%d",a,b);

    return 0;
}
